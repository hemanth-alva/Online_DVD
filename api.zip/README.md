I have manually inserted the data into the database
I'm have also attached the sells.csv file(table) in the zip file.
