const express = require('express');
const router = express.Router();
const db = require('../config/database');
const Sell = require('../models/Sell');
const Sequelize = require('sequelize');
const Op = Sequelize.Op;

// Get sell list
router.get('/', (req,res) => 
    Sell.findAll()
    .then(sells => res.render('sells', {
            sells
        }))
    .catch(err => console.log(err)));

//Display add Sell form
router.get('/add',(req,res) => res.render('add'));


//Add a sell
router.post('/add', (req, res) =>{
    let { movieTitle, releaseYear, length, director, plot, cast, imdb, language, genre, mrp, inventory, sellingPrice, shippingFee, isSellable, soldCount} = req.body;
    let errors = [];

    if(!movieTitle) {
        errors.push({text: 'Please add a title'});
    }
    if(!releaseYear) {
        errors.push({text: 'Please add a release year'});
    }
    if(!length) {
        errors.push({text: 'Please add a the length of the movie'});
    }
    if(!director) {
        errors.push({text: 'Please add the director name'});
    }
    if(!plot) {
        errors.push({text: 'Please add the plot of the movie'});
    }
    if(!cast) {
        errors.push({text: 'Please add the cast '});
    }
    if(!imdb) {
        errors.push({text: 'Please add the imdb ratting '});
    }
    if(!language) {
        errors.push({text: 'Please add the language of the movie '});
    }
    if(!genre) {
        errors.push({text: 'Please add the genre '});
    }

    //Check for errors
    if(errors.length > 0) {
        res.render('add',{
            errors,
            movieTitle,
            releaseYear, 
            length, 
            director, 
            plot, 
            cast, 
            imdb, 
            language, 
            genre, 
            mrp, 
            inventory, 
            sellingPrice, 
            shippingFee, 
            isSellable, 
            soldCount
        });
    } else{
        //remove space after coma
        genre = genre.replace(/, /g,',');

        // Insert into table
        Sell.create({
            movieTitle,
            releaseYear,
            length,
            director,
            plot,
            cast,
            imdb,
            language,
            genre,
            mrp,
            inventory,
            sellingPrice,
            shippingFee,
            isSellable,
            soldCount
        })
            .then(sell => res.redirect('/sells'))
            .catch(err => console.log(err));
    }
});

//delete a sell
router.post('/delete', (req, res) =>{
    let {id, movieTitle} = req.body;
    let errors = [];

        // delete from table
        Sell.destroy({
            where:{ id }
        })
            .then(sell => res.redirect('/sells'))
            .catch(err => console.log(err));
});



//Search for sells
router.get('/search', (req,res) => {
    const { term } = req.query;

    Sell.findAll({ where: {movieTitle: {[Op.like]: '%'+ term +'%'}}})
    .then(sells => res.render('sells',{ sells }))
    .catch(err => console.log(err));
});



module.exports = router;