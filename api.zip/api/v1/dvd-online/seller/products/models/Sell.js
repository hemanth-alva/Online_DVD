const Sequelize = require('sequelize');
const db = require('../config/database');
const Sell = db.define('sell', {
    movieTitle: {
        type: Sequelize.STRING
    },
    releaseYear: {
        type: Sequelize.INTEGER
    },
    length: {
        type: Sequelize.STRING
    },
    director: {
        type: Sequelize.STRING
    },
    plot: {
        type: Sequelize.STRING
    },
    cast: {
        type: Sequelize.STRING
    },
    imdb: {
        type: Sequelize.STRING
    },
    language: {
        type: Sequelize.STRING
    },
    genre: {
        type: Sequelize.STRING
    },
    mrp: {
        type: Sequelize.BIGINT
    },
    inventory: {
        type: Sequelize.BIGINT
    },
    sellingPrice: {
        type: Sequelize.BIGINT
    },
    shippingFee: {
        type: Sequelize.BIGINT
    },
    isSellable: {
        type: Sequelize.BOOLEAN
    },
    soldCount: {
        type: Sequelize.BIGINT
    }
})

module.exports = Sell;